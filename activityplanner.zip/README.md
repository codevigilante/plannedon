# Planned On

Hello. Planned On is a linear calendar app that lets you plan events and activities without relying on time.

## Technology

PHP 7.0
Codeigniter 3
Parsley javascript form validation
MySQL