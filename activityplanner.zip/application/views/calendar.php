<div class="container-fluid">
          <div class="row match-my-cols calendar-grid" id="week-0">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 activity-week text-center">
                        <p id="start-date-0"></p>
                        <p>to</p>
                        <p id="end-date-0"></p>
                    </div>
                    <div class="col-md-3" id="mon-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                    <div class="col-md-3" id="tue-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                    <div class="col-md-3" id="wed-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3" id="thu-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                    <div class="col-md-3" id="fri-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                    <div class="col-md-3" id="sat-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                    <div class="col-md-3" id="sun-0">
                        <div class="day-heading"></div>
                        <div class="list-group">
                            <!--
                            <a href="#" class="list-group-item active">
                                Cras justo odio
                            </a>
                            <a href="#" class="list-group-item"><span class="label label-primary">AM</span> This is an activity that takes up a lot of space</a>
                            <a href="#" class="list-group-item"><span class="label label-primary">1200</span> Gym - squats</a>
                            -->
                        </div>
                        <div class="activity text-center"><button type="button" class="btn btn-default btn-xs" aria-label="Left Align"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
                    </div>
                </div>      
            </div>
        </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?=base_url();?>assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>