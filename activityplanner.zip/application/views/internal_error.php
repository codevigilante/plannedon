
    <div class="container">        
        <div class="jumbotron">
            <h1 class="text-center">What Happened?</h1>
            <h3 class="text-center">There was a problem...</h3>
            <hr />
            <p class="text-center"><?=$err_msg;?></p>
        </div>
    </div>
  </body>
</html>